/**
 * 
 */
/**
 * @author restonpiston
 *
 */
package sopa.modelo;
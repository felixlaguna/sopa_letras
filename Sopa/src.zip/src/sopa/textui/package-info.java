/**
 * 
 */
/**
 * @author restonpiston
 *
 */
package sopa.textui;